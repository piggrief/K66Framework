#ifndef __Serial_oscilloscope_H__
#define __Serial_oscilloscope_H__

void Data_Send(UARTn_e uratn,unsigned short int *data);


#endif